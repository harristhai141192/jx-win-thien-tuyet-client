SKILLS={
	--��ղ�����
	jingangbuhuai={ --��ղ�����
		fastwalkrun_p={{{1,-100},{2,-100}},{{1,-1},{20,-1}}},
		meleedamagereturn_p={
					{{1,100},{2,100}},
					{{1,1},{2,1}},
					{{1,1},{2,1}},
			},
		rangedamagereturn_p={
					{{1,100},{2,100}},
					{{1,1},{2,1}},
					{{1,1},{2,1}},
			}
				
	},
	
	
	
}
Include("\\script\\skill\\head.lua")