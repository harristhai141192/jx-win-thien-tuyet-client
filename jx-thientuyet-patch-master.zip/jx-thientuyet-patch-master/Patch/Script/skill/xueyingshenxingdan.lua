SKILLS={
	--ѪӰ���е�
	xueyingshenxing={ --ѪӰ���е�
		fastwalkrun_p={{{1,100},{2,100}},{{1,-1},{20,-1}}},
		allresmax_p={
				{{1,-20},{2,-20}},
				{{1,-1},{2,-1}},
				{{1,-1},{2,-1}},
			}			
	},
	
	
	
}
Include("\\script\\skill\\head.lua")