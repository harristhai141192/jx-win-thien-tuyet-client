Include("\\script\\skill\\head.lua")
SKILLS={
	luohan_zhen={ --�޺���
		addphysicsdamage_p={{{1,11},{20,135}},{{1,18},{2,18}},{{1,6},{2,6}}},
		meleedamagereturn_p={{{1,5},{30,150}},{{1,18},{2,18}}},
		rangedamagereturn_p={{{1,5},{30,150}},{{1,18},{2,18}}},
		adddefense_v={{{1,40},{20,800}},{{1,18},{2,18}}},
	}
}

