function GetSkillLevelData(levelname, data, level)

if (levelname == "magicdamage_v") then
return Getmagicdamage_v(level)
end;

str1 = ""
return str1
end;

function Param2String(Param1, Param2, Param3)
return Param1..","..Param2..","..Param3
end;

function Getmagicdamage_v(level)
result1 = 10000
return Param2String(result1,0,result1)
end;